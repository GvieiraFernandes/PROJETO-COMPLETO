<?php
require_once 'db_config.php';

$mensagem = "";

function cadastrarEntregador($nome, $email, $cpf, $telefone, $senha)
{
    global $conn;
    $nome = $conn->real_escape_string($nome);
    $email = $conn->real_escape_string($email);
    $cpf = $conn->real_escape_string($cpf);
    $telefone = $conn->real_escape_string($telefone);
    $senha = $conn->real_escape_string($senha);

    if (verificarEmailExistenteEntregador($email)) {
        return false; // Email já existe, retorna falso
    }

    $sql = "INSERT INTO entregador (nome, email, cpf, telefone, senha) VALUES ('$nome', '$email', '$cpf', '$telefone', '$senha')";

    if ($conn->query($sql) === true) {
        return true;
    } else {
        return false;
    }
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $cpf = $_POST['cpf'];
    $telefone = $_POST['telefone'];
    $senha = $_POST['senha'];

    if (cadastrarEntregador($nome, $email, $cpf, $telefone, $senha)) {
        echo "Cadastro realizado com sucesso.";
    } else {
        echo "O Cadastro já existe.";
    }
}
?>

<!DOCTYPE html>
<html>
<link rel="stylesheet" type="text/css" href="CSS/cadastro_entregador">
<script src="JS/cadastro_entregador.js"></script>

<head>
    <title>Cadastro de Entregador</title>

</head>

<body>

    <form method="POST" action="">

        <h1>Cadastro de Entregador</h1>
        <label for="nome">Nome:</label><br>
        <input type="text" id="nome" name="nome" required><br>

        <label for="email">E-mail:</label><br>
        <input type="email" id="email" name="email" required><br>

        <label for="cpf">CPF:</label><br>
        <input type="text" id="cpf" name="cpf" required><br>

        <label for="telefone">Telefone:</label><br>
        <input type="text" id="telefone" name="telefone" required><br>

        <label for="senha">Senha:</label><br>
        <input type="password" id="senha" name="senha" required><br>

        <input type="submit" value="Cadastrar">

        
        <?php if (isset($mensagem)): ?>
            <span><?php echo $mensagem; ?></span>
        <?php endif; ?>
       

        <div class="links">
            <p>Se já tem cadastro, <a href="login.php">clique aqui para logar</a></p>
            <a href="recuperar_senha.php">Esqueceu a senha?</a>
        </div>
    </form>

</body>

</html>