
function maskCNPJ(input) {
    input.value = input.value.replace(/\D/g, "");
    input.value = input.value.replace(/^(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/, "$1.$2.$3/$4-$5");
}

function maskTelefone(input) {
    input.value = input.value.replace(/\D/g, ""); 
    input.value = input.value.replace(/(\d{2})(\d{4,5})(\d{4})/, "($1) $2-$3");
}


function maskCEP(input) {
    input.value = input.value.replace(/\D/g, "");
    input.value = input.value.replace(/(\d{5})(\d{3})/, "$1-$2");
}

function validateForm() {
    var cnpj = document.getElementById('cnpj');
    var telefone = document.getElementById('telefone');
    var cep = document.getElementById('cep');

    if (!cnpjIsValid(cnpj.value)) {
        alert('CNPJ inválido');
        return false;
    }

    if (!telefoneIsValid(telefone.value)) {
        alert('Telefone inválido');
        return false;
    }

    if (!cepIsValid(cep.value)) {
        alert('CEP inválido');
        return false;
    }

    return true;
}

function cnpjIsValid(cnpj) {
    if (cnpj.length !== 18) {
        return false;
    }

    // Implemente a validação do CNPJ, se necessário

    return true;
}

function telefoneIsValid(telefone) {
    if (telefone.length !== 14) {
        return false;
    }

    // Implemente a validação do telefone, se necessário

    return true;
}

function cepIsValid(cep) {
    if (cep.length !== 9) {
        return false;
    }

    // Implemente a validação do CEP, se necessário

    return true;
}




