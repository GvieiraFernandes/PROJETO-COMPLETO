<!DOCTYPE html>
<html>
<head>
    <title>Escolha o Tipo de Cadastro</title>
    <link rel="stylesheet" type="text/css" href="CSS/escolha_cadastro.css">
</head>
<body>
    <div class="container">
        <h1>ESCOLHA O TIPO DE CADASTRO</h1>
        <ul class="cadastro-options">
            <li><a href="cadastro_usuario.php">Cadastro de Usuário</a></li>
            <li><a href="cadastro_entregador.php">Cadastro de Entregador</a></li>
            <li><a href="cadastro_restaurante.php">Cadastro de Restaurante</a></li>
        </ul>
    </div>
</body>
</html>
