const orderCountElement = document.getElementById('orderCount');
let orderCount = localStorage.getItem('orderCount') ? parseInt(localStorage.getItem('orderCount')) : 0;
updateOrderDisplay();

document.getElementById('addOrder').addEventListener('click', function() {
    orderCount++;
    localStorage.setItem('orderCount', orderCount);
    updateOrderDisplay();
});

function updateOrderDisplay() {
    orderCountElement.textContent = orderCount;
}
