<?php
session_start();
require_once '/xampp/htdocs/Vita4u/db_config.php';

// Verifica se o usuário está autenticado
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}

// Recupera as informações do perfil do usuário do banco de dados
$id_usuario = $_SESSION['usuario']['id_usuario'];
$sql = "SELECT * FROM usuario WHERE id_usuario = '$id_usuario'";
$result = $conn->query($sql);

if ($result->num_rows == 1) {
    $perfil = $result->fetch_assoc();
} else {
    // Perfil não encontrado
    header("Location: login.php");
    exit();
}

// Processa o formulário de edição de perfil
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $telefone = $_POST['telefone'];
    $cpf = $_POST['cpf'];
    $cep = $_POST['cep'];
    $senha = $_POST['senha'];

    $sql = "UPDATE usuario SET nome = '$nome', email = '$email', telefone = '$telefone', cpf = '$cpf', cep = '$cep', senha = '$senha' WHERE id_usuario = '$id_usuario'";
    if ($conn->query($sql) === TRUE) {
        $mensagem = "Perfil atualizado com sucesso.";
    } else {
        $mensagem = "Erro ao atualizar o perfil: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Editar Perfil do Usuário</title>
    <link rel="stylesheet" type="text/css" href="../CSS/editar_perfil_usuario.css">
</head>
<body>
    <div class="container">
        <h1>Editar Perfil</h1>
        <?php if (isset($mensagem)): ?>
            <div class="message"><?php echo $mensagem; ?></div>
        <?php endif; ?>
        <form method="POST" action="">
            <label for="nome">Nome:</label>
            <input type="text" id="nome" name="nome" value="<?php echo $perfil['nome']; ?>" required>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" value="<?php echo $perfil['email']; ?>" required>

            <label for="telefone">Telefone:</label>
            <input type="text" id="telefone" name="telefone" value="<?php echo $perfil['telefone']; ?>" required>

            <label for="cpf">CPF:</label>
            <input type="text" id="cpf" name="cpf" value="<?php echo $perfil['cpf']; ?>" required>

            <label for="cep">CEP:</label>
            <input type="text" id="cep" name="cep" value="<?php echo $perfil['cep']; ?>" required>

            <label for="senha">Senha:</label>
            <input type="password" id="senha" name="senha" value="<?php echo $perfil['senha']; ?>" required>

            <input type="submit" value="Salvar Alterações">
        </form>
    </div>
    
    <script>
    // Função para máscara de CPF
    function mascaraCPF(cpf) {
        cpf = cpf.replace(/\D/g, ''); // Remove todos os caracteres não numéricos
        if (cpf.length > 11) {
            cpf = cpf.slice(0, 11); // Limita o CPF a 11 dígitos
        }
        if (cpf.length < 4) return cpf;
        if (cpf.length < 7) return cpf.replace(/(\d{3})(\d+)/, '$1.$2');
        if (cpf.length < 10) return cpf.replace(/(\d{3})(\d{3})(\d+)/, '$1.$2.$3');
        return cpf.replace(/(\d{3})(\d{3})(\d{3})(\d+)/, '$1.$2.$3-$4');
    }

    // Função para máscara de telefone (11) 12345-1234
    function mascaraTelefone(telefone) {
        telefone = telefone.replace(/\D/g, ''); // Remove todos os caracteres não numéricos
        if (telefone.length > 11) {
            telefone = telefone.slice(0, 11); // Limita o telefone a 11 dígitos
        }
        if (telefone.length < 2) return '(' + telefone;
        if (telefone.length < 7) return '(' + telefone.replace(/(\d{2})(\d+)/, '$1) $2');
        return '(' + telefone.replace(/(\d{2})(\d{5})(\d+)/, '$1) $2-$3');
    }

    // Função para máscara de CEP 12345-123
    function mascaraCEP(cep) {
        cep = cep.replace(/\D/g, ''); // Remove todos os caracteres não numéricos
        if (cep.length > 8) {
            cep = cep.slice(0, 8); // Limita o CEP a 8 dígitos
        }
        if (cep.length < 6) return cep;
        return cep.replace(/(\d{5})(\d+)/, '$1-$2');
    }

    // Aplicando as máscaras aos campos
    document.getElementById('cpf').addEventListener('input', function (e) {
        e.target.value = mascaraCPF(e.target.value);
    });

    document.getElementById('telefone').addEventListener('input', function (e) {
        e.target.value = mascaraTelefone(e.target.value);
    });

    document.getElementById('cep').addEventListener('input', function (e) {
        e.target.value = mascaraCEP(e.target.value);
    });
</script>
</body>
</html>

