<?php
    require_once("mail.php");
    $destinatario = $_POST["destinatario"];
    $assunto = $_POST["assunto"];
    $corpo = $_POST["corpo"];

    send_mail($destinatario, $assunto, $corpo);
?>