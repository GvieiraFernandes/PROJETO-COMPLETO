<?php
require_once 'db_config.php';
require_once 'email_config.php';

function recuperarSenhaUsuario($email)
{
    global $conn;
    $email = $conn->real_escape_string($email);

    $sql = "SELECT * FROM usuario WHERE email = '$email'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $senha = gerarSenhaAleatoria();
        $hashedSenha = ($senha);

        $sql = "UPDATE usuario SET senha = '$hashedSenha' WHERE email = '$email'";
        if ($conn->query($sql) === true) {
            $assunto = 'Recuperacao de Senha';
            $mensagem = 'Essa e sua nova senha, por favor troque na aba editar perfil no seu Login, e apenas uma senha temporaria: ' . $senha;
            if (enviarEmail($email, $assunto, $mensagem)) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    } else {
        return false;
    }
}

function recuperarSenhaEntregador($email)
{
    global $conn;
    $email = $conn->real_escape_string($email);

    $sql = "SELECT * FROM entregador WHERE email = '$email'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $senha = gerarSenhaAleatoria();
        $hashedSenha = ($senha);

        $sql = "UPDATE entregador SET senha = '$hashedSenha' WHERE email = '$email'";
        if ($conn->query($sql) === true) {
            $assunto = 'Recuperacao de Senha';
            $mensagem = 'Essa e sua nova senha, por favor troque na aba editar perfil no seu Login, e apenas uma senha temporaria: ' . $senha;
            if (enviarEmail($email, $assunto, $mensagem)) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    } else {
        return false;
    }
}

function recuperarSenhaRestaurante($email)
{
    global $conn;
    $email = $conn->real_escape_string($email);

    $sql = "SELECT * FROM restaurante WHERE email = '$email'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $senha = gerarSenhaAleatoria();
        $hashedSenha = ($senha);

        $sql = "UPDATE restaurante SET senha = '$hashedSenha' WHERE email = '$email'";
        if ($conn->query($sql) === true) {
            $assunto = 'Recuperacao de Senha';
            $mensagem = 'Essa e sua nova senha, por favor troque na aba editar perfil no seu Login, e apenas uma senha temporaria: ' . $senha;
            if (enviarEmail($email, $assunto, $mensagem)) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    } else {
        return false;
    }
}

function gerarSenhaAleatoria($tamanho = 8)
{
    $caracteres = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    $senha = '';
    for ($i = 0; $i < $tamanho; $i++) {
        $senha .= $caracteres[rand(0, strlen($caracteres) - 1)];
    }
    return $senha;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = htmlspecialchars($_POST['email']);

    if (recuperarSenhaUsuario($email) || recuperarSenhaEntregador($email) || recuperarSenhaRestaurante($email)) {
        echo "Um e-mail foi enviado para o endereço fornecido com as instruções para recuperar a senha.";
    } else {
        echo "Erro ao recuperar senha.";
    }
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Recuperar Senha</title>
</head>

<body>
    <h1>Recuperar Senha</h1>
    <form method="POST" action="">
        <label for="email">E-mail:</label><br>
        <input type="email" id="email" name="email" required><br>

        <input type="submit" value="Recuperar Senha">
    </form>
</body>

</html>
