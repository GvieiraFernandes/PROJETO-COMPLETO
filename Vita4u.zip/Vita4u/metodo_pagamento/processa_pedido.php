<?php
// Inclua o arquivo de configuração do banco de dados que contenha a conexão
require_once '/xampp/htdocs/Vita4u/db_config.php';

$metodo_pagamento = $_POST['metodo_pagamento'];

if ($metodo_pagamento === 'pix') {
    // Processar pagamento via Pix
    // Inclua aqui o código para lidar com pagamentos via Pix
} elseif ($metodo_pagamento === 'cartao') {
    // Busque todos os cartões cadastrados no banco de dados
    $query = "SELECT id_cartao, nome_titular FROM cartoes";
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $stmt->bind_result($id_cartao, $nome_titular);

    // Gere as opções para o campo de seleção
    while ($stmt->fetch()) {
        echo '<option value="' . $id_cartao . '">' . $nome_titular . '</option>';
    }

    $stmt->close();
} elseif ($metodo_pagamento === 'dinheiro') {
    // Processar pagamento em Dinheiro
    $valor_em_dinheiro = $_POST['valor_em_dinheiro'];
    
    // Inclua aqui o código para lidar com pagamentos em Dinheiro
}

// Resto do código de processamento do pedido...

// Feche a conexão com o banco de dados no final do arquivo, se necessário
$conn->close();
?>


