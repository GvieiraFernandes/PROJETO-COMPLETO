<?php
session_start();
require_once '/xampp/htdocs/Vita4u/db_config.php';

// Verifica se o restaurante está autenticado
if (!isset($_SESSION['restaurante'])) {
    header("Location: login.php");
    exit();
}

// Recupera as informações do perfil do restaurante do banco de dados
$id_restaurante = $_SESSION['restaurante']['id_restaurante'];
$sql = "SELECT * FROM restaurante WHERE id_restaurante = '$id_restaurante'";
$result = $conn->query($sql);

if ($result->num_rows == 1) {
    $perfil = $result->fetch_assoc();
} else {
    // Perfil não encontrado
    header("Location: login.php");
    exit();
}

// Processa o formulário de edição de perfil
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $cnpj = $_POST['cnpj'];
    $telefone = $_POST['telefone'];
    $cep = $_POST['cep'];
    $bairro = $_POST['bairro'];
    $endereco = $_POST['endereco'];
    $cidade = $_POST['cidade'];
    $estado = $_POST['estado'];
    $senha = $_POST['senha'];

    // Atualiza as informações do perfil no banco de dados
    $sql = "UPDATE restaurante SET nome = '$nome', email = '$email', cnpj = '$cnpj', telefone = '$telefone', cep = '$cep', bairro = '$bairro', endereco = '$endereco', cidade = '$cidade', estado = '$estado', senha = '$senha' WHERE id_restaurante = '$id_restaurante'";
    if ($conn->query($sql) === TRUE) {
        $mensagem = "Perfil atualizado com sucesso.";
    } else {
        $mensagem = "Erro ao atualizar o perfil: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Editar Perfil do Restaurante</title>
    <link rel="stylesheet" type="text/css" href="../CSS/editar_perfil_restaurante.css">
</head>
<body>
    <div class="container">
        <h1>Editar Perfil</h1>
        <?php if (isset($mensagem)): ?>
            <div class="message"><?php echo $mensagem; ?></div>
        <?php endif; ?>
        <form method="POST" action="">
            <label for="nome">Nome:</label>
            <input type="text" id="nome" name="nome" value="<?php echo $perfil['nome']; ?>" required>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" value="<?php echo $perfil['email']; ?>" required>

            <label for="cnpj">CNPJ:</label>
            <input type="text" id="cnpj" name="cnpj" value="<?php echo $perfil['cnpj']; ?>" required>

            <label for="telefone">Telefone:</label>
            <input type="text" id="telefone" name="telefone" value="<?php echo $perfil['telefone']; ?>" required>
            
            <label for="cep">CEP:</label>
            <input type="text" id="cep" name="cep" value="<?php echo $perfil['cep']; ?>" required>

            <label for="bairro">Bairro:</label>
            <input type="text" id="bairro" name="bairro" value="<?php echo $perfil['bairro']; ?>" required>

            <label for="endereco">Endereço:</label>
            <input type="text" id="endereco" name="endereco" value="<?php echo $perfil['endereco']; ?>" required>

            <label for="cidade">Cidade:</label>
            <input type="text" id="cidade" name="cidade" value="<?php echo $perfil['cidade']; ?>" required>

            <label for="estado">Estado:</label>
            <input type="text" id="estado" name="estado" value="<?php echo $perfil['estado']; ?>" required>

            <label for="senha">Senha:</label>
            <input type="password" id="senha" name="senha" required>

            <input type="submit" value="Salvar Alterações">
        </form>
    </div>

    <script>
    // Função para máscara de CNPJ
    function mascaraCNPJ(cnpj) {
        cnpj = cnpj.replace(/\D/g, ''); // Remove todos os caracteres não numéricos
        if (cnpj.length > 14) {
            cnpj = cnpj.slice(0, 14); // Limita o CNPJ a 14 dígitos
        }
        if (cnpj.length < 3) return cnpj;
        if (cnpj.length < 7) return cnpj.replace(/(\d{2})(\d+)/, '$1.$2');
        if (cnpj.length < 11) return cnpj.replace(/(\d{2})(\d{3})(\d+)/, '$1.$2.$3');
        return cnpj.replace(/(\d{2})(\d{3})(\d{3})(\d+)/, '$1.$2.$3/$4');
    }

    // Função para máscara de telefone (11) 12345-1234
    function mascaraTelefone(telefone) {
        telefone = telefone.replace(/\D/g, ''); // Remove todos os caracteres não numéricos
        if (telefone.length > 11) {
            telefone = telefone.slice(0, 11); // Limita o telefone a 11 dígitos
        }
        if (telefone.length < 2) return '(' + telefone;
        if (telefone.length < 7) return '(' + telefone.replace(/(\d{2})(\d+)/, '$1) $2');
        return '(' + telefone.replace(/(\d{2})(\d{5})(\d+)/, '$1) $2-$3');
    }

    // Função para máscara de CEP 12345-123
    function mascaraCEP(cep) {
        cep = cep.replace(/\D/g, ''); // Remove todos os caracteres não numéricos
        if (cep.length > 8) {
            cep = cep.slice(0, 8); // Limita o CEP a 8 dígitos
        }
        if (cep.length < 5) return cep;
        return cep.replace(/(\d{5})(\d+)/, '$1-$2');
    }

    // Aplicando as máscaras aos campos
    document.getElementById('cnpj').addEventListener('input', function (e) {
        e.target.value = mascaraCNPJ(e.target.value);
    });

    document.getElementById('telefone').addEventListener('input', function (e) {
        e.target.value = mascaraTelefone(e.target.value);
    });

    document.getElementById('cep').addEventListener('input', function (e) {
        e.target.value = mascaraCEP(e.target.value);
    });
</script>

</body>
</html>


