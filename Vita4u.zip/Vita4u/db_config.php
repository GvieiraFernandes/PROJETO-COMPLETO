<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "vita4u";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Falha na conexão com o banco de dados: " . $conn->connect_error);
}

function verificarEmailExistenteEntregador($email)
{
    global $conn;
    $email = $conn->real_escape_string($email);

    $sql = "SELECT COUNT(*) AS count FROM entregador WHERE email = '$email'";
    $result = $conn->query($sql);

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        if ($row['count'] > 0) {
            return true;
        }
    }

    return false;
}

function verificarEmailExistenteRestaurante($email) {
    global $conn;
    $sql = "SELECT email FROM restaurante WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->num_rows > 0; 
}

function verificarEmailExistenteUsuario($email) {
    global $conn;
    $sql = "SELECT email FROM usuario WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->num_rows > 0; 
}

?>
