<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
   
    $nome = $_POST["nome"];
    $descricao = $_POST["descricao"];
    $data_inicio = $_POST["data_inicio"];
    $data_fim = $_POST["data_fim"];
    $desconto = $_POST["desconto"];

    $servidor = "localhost";
	$usuario = "root";
	$senha = "";
	$dbname = "vita4u";
	
	//Criar a conexao
	$conexao = mysqli_connect($servidor, $usuario, $senha, $dbname);
   
 
    if ($conexao->connect_error) {
        die("Erro na conexão: " . $conexao->connect_error);
    }

   
    $sql = "INSERT INTO promocoes (nome, descricao, data_inicio, data_fim, desconto) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conexao->prepare($sql);
    $stmt->bind_param("ssssd", $nome, $descricao, $data_inicio, $data_fim, $desconto);

    if ($stmt->execute()) {
        header("Location: promocoes.php"); 
    } else {
        echo "Erro ao adicionar a promoção: " . $stmt->error;
    }

    
    $conexao->close();
}
?>
