<?php
if (isset($_GET["id"])) {
    $id = $_GET["id"];

    $servidor = "localhost";
	$usuario = "root";
	$senha = "";
	$dbname = "vita4u";
	
	$conexao = mysqli_connect($servidor, $usuario, $senha, $dbname);

   
    if ($conexao->connect_error) {
        die("Erro na conexão: " . $conexao->connect_error);
    }

    $sql = "SELECT * FROM promocoes WHERE id = ?";
    $stmt = $conexao->prepare($sql);
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        $result = $stmt->get_result();
        if ($result->num_rows === 1) {
            $row = $result->fetch_assoc();
        } else {
            echo "Promoção não encontrada.";
            exit;
        }
    } else {
        echo "Erro ao recuperar dados da promoção: " . $stmt->error;
        exit;
    }

    $conexao->close();
}
?>
<!DOCTYPE html>
<html>
    <link rel="stylesheet" href="edita.css">
<head>
    <title>Editar Promoção</title>
</head>
<body>
    <h1>Editar Promoção</h1>
    <form action="processar_edicao.php" method="POST">
        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
        
        <label for="nome">Nome da Promoção:</label>
        <input type="text" id="nome" name="nome" value="<?php echo $row['nome']; ?>" required><br><br>
        
        <label for="descricao">Descrição da Promoção:</label>
        <textarea id="descricao" name="descricao" required><?php echo $row['descricao']; ?></textarea><br><br>
        
        <label for="data_inicio">Data de Início:</label>
        <input type="date" id="data_inicio" name="data_inicio" value="<?php echo $row['data_inicio']; ?>" required><br><br>
        
        <label for="data_fim">Data de Término:</label>
        <input type="date" id="data_fim" name="data_fim" value="<?php echo $row['data_fim']; ?>" required><br><br>
        
        <label for="desconto">Desconto:</label>
        <input type="number" id="desconto" name="desconto" step="0.01" value="<?php echo $row['desconto']; ?>" required> %<br><br>
        
        <input type="submit" value="Editar Promoção">
    </form>
</body>
</html>
