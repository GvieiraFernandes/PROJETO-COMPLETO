<?php
session_start();
require_once '/xampp/htdocs/Vita4u/db_config.php';

// Verifica se o entregador está autenticado
if (!isset($_SESSION['entregador'])) {
    header("Location: login.php");
    exit();
}

// Recupera as informações do perfil do entregador do banco de dados
$id_entregador = $_SESSION['entregador']['id_entregador'];
$sql = "SELECT * FROM entregador WHERE id_entregador = '$id_entregador'";
$result = $conn->query($sql);

if ($result->num_rows == 1) {
    $perfil = $result->fetch_assoc();
} else {
    // Perfil não encontrado
    header("Location: login.php");
    exit();
}

// Processa o formulário de edição de perfil
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $cpf = $_POST['cpf'];
    $telefone = $_POST['telefone'];
    $senha = $_POST['senha'];

    // Atualiza as informações do perfil no banco de dados
    $sql = "UPDATE entregador SET nome = '$nome', email = '$email', cpf = '$cpf', telefone = '$telefone', senha = '$senha' WHERE id_entregador = '$id_entregador'";
    if ($conn->query($sql) === TRUE) {
        $mensagem = "Perfil atualizado com sucesso.";
    } else {
        $mensagem = "Erro ao atualizar o perfil: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Editar Perfil do Entregador</title>
    <link rel="stylesheet" type="text/css" href="../CSS/editar_perfil_entregador.css">
</head>
<body>
    <div class="container">
        <h1>Editar Perfil</h1>
        <?php if (isset($mensagem)): ?>
            <div class="message"><?php echo $mensagem; ?></div>
        <?php endif; ?>
        <form method="POST" action="">
            <label for="nome">Nome:</label>
            <input type="text" id="nome" name="nome" value="<?php echo $perfil['nome']; ?>" required>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" value="<?php echo $perfil['email']; ?>" required>

            <label for="cpf">CPF:</label>
            <input type="text" id="cpf" name="cpf" value="<?php echo $perfil['cpf']; ?>" required>

            <label for="telefone">Telefone:</label>
            <input type="text" id="telefone" name="telefone" value="<?php echo $perfil['telefone']; ?>" required>

            <label for="senha">Senha:</label>
            <input type="password" id="senha" name="senha" value="<?php echo $perfil['senha']; ?>" required>

            <input type="submit" value="Salvar Alterações">
        </form>
    </div>

    <script>
    // Função para máscara de CPF
    function mascaraCPF(cpf) {
        cpf = cpf.replace(/\D/g, ''); // Remove todos os caracteres não numéricos
        if (cpf.length > 11) {
            cpf = cpf.slice(0, 11); // Limita o CPF a 11 dígitos
        }
        if (cpf.length < 4) return cpf;
        if (cpf.length < 7) return cpf.replace(/(\d{3})(\d+)/, '$1.$2');
        if (cpf.length < 10) return cpf.replace(/(\d{3})(\d{3})(\d+)/, '$1.$2.$3');
        return cpf.replace(/(\d{3})(\d{3})(\d{3})(\d+)/, '$1.$2.$3-$4');
    }

    // Função para máscara de telefone (11) 12345-1234
    function mascaraTelefone(telefone) {
        telefone = telefone.replace(/\D/g, ''); // Remove todos os caracteres não numéricos
        if (telefone.length > 11) {
            telefone = telefone.slice(0, 11); // Limita o telefone a 11 dígitos
        }
        if (telefone.length < 2) return '(' + telefone;
        if (telefone.length < 7) return '(' + telefone.replace(/(\d{2})(\d+)/, '$1) $2');
        return '(' + telefone.replace(/(\d{2})(\d{5})(\d+)/, '$1) $2-$3');
    }

    // Aplicando as máscaras aos campos
    document.getElementById('cpf').addEventListener('input', function (e) {
        e.target.value = mascaraCPF(e.target.value);
    });

    document.getElementById('telefone').addEventListener('input', function (e) {
        e.target.value = mascaraTelefone(e.target.value);
    });
</script>


</body>
</html>
