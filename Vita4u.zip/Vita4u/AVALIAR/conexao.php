<?php
	$servidor = "localhost";
	$usuario = "root";
	$senha = "";
	$dbname = "vita4u";
	
	//Criar a conexao
	$conn = mysqli_connect($servidor, $usuario, $senha, $dbname);
    ?> 