<?php
require_once 'db_config.php';

$mensagem = "";

function cadastrarUsuario($nome, $email, $cpf, $telefone, $cep, $senha)
{
    global $conn;
    $nome = $conn->real_escape_string($nome);
    $email = $conn->real_escape_string($email);
    $cpf = $conn->real_escape_string($cpf);
    $telefone = $conn->real_escape_string($telefone);
    $cep = $conn->real_escape_string($cep);
    $senha = $conn->real_escape_string($senha);

    if (verificarEmailExistenteUsuario($email)) {
        return false; // Email já existe, retorna falso
    }

    $sql = "INSERT INTO usuario (nome, email, cpf, telefone, cep, senha) VALUES ('$nome', '$email', '$cpf', '$telefone', '$cep', '$senha')";

    if ($conn->query($sql) === true) {
        return true;
    } else {
        return false;
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $cpf = $_POST['cpf'];
    $telefone = $_POST['telefone'];
    $cep = $_POST['cep'];
    $senha = $_POST['senha'];

    if (cadastrarUsuario($nome, $email, $cpf, $telefone, $cep, $senha)) {
        echo "Cadastro realizado com sucesso.";
    } else {
        echo "O Cadastro já existe.";
    }
}

?>

<!DOCTYPE html>
<html>

<head>
    <title>Cadastro de Usuário</title>
    <link rel="stylesheet" type="text/css" href="CSS/cadastro_usuario.css">
</head>

<body>
    <div class="container">
        <form method="POST" action="">
        <h1>Cadastro de Usuário</h1>
            <label for="nome">Nome:</label>
            <input type="text" id="nome" name="nome" required>

            <label for="email">E-mail:</label>
            <input type="email" id="email" name="email" required>

            <label for="telefone">Telefone:</label>
            <input type="text" id="telefone" name="telefone" required>

            <label for="cpf">CPF:</label>
            <input type="text" id="cpf" name="cpf" required>

            <label for="cep">CEP:</label>
            <input type="text" id="cep" name="cep" required>

            <label for="senha">Senha:</label>
            <input type="password" id="senha" name="senha" required>

            <input type="submit" value="Cadastrar">

            <?php if (!empty($mensagem)): ?>
            <span><?php echo $mensagem; ?></span>
            <?php endif; ?>

            <div class="links">
            <p>Se já tem cadastro, <a href="login.php">clique aqui para logar</a></p>
            <a href="recuperar_senha.php">Esqueceu a senha?</a>
            </div>

        </form>
        
    </div>
</body>

<script>
        const form = document.getElementById('cadastroForm');
        const cpfInput = document.getElementById('cpf');
        const telefoneInput = document.getElementById('telefone');
        const cepInput = document.getElementById('cep');
        const emailInput = document.getElementById('email');

        // Máscara para CPF (XXX.XXX.XXX-XX)
        cpfInput.addEventListener('input', function () {
            let value = cpfInput.value.replace(/\D/g, '');

            if (value.length > 11) {
                value = value.slice(0, 11);
            }

            cpfInput.value = value.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4');
        });

        // Máscara para telefone (XX XXXXX-XXXX)
        telefoneInput.addEventListener('input', function () {
            let value = telefoneInput.value.replace(/\D/g, '');

            if (value.length > 11) {
                value = value.slice(0, 11);
            }

            telefoneInput.value = value.replace(/(\d{2})(\d{5})(\d{4})/, '($1) $2-$3');
        });

        // Máscara para CEP (XXXXX-XXX)
        // Máscara para CEP (XXXXX-XXX)
cepInput.addEventListener('input', function () {
    let value = cepInput.value.replace(/\D/g, '');

    if (value.length > 8) {
        value = value.slice(0, 8);
    }

    cepInput.value = value.replace(/(\d{5})(\d{3})/, '$1-$2');
});

        // Validação de e-mail simples (verifica se contém @)
        emailInput.addEventListener('input', function () {
            if (!emailInput.value.includes('@')) {
                emailInput.setCustomValidity('Insira um endereço de e-mail válido.');
            } else {
                emailInput.setCustomValidity('');
            }
        });

        // Validação de CPF simples (verifica se tem 11 dígitos)
        cpfInput.addEventListener('input', function () {
            if (cpfInput.value.replace(/\D/g, '').length !== 11) {
                cpfInput.setCustomValidity('CPF inválido. Insira 11 dígitos.');
            } else {
                cpfInput.setCustomValidity('');
            }
        });

        // Validação de telefone simples (verifica se tem 11 ou 10 dígitos)
        telefoneInput.addEventListener('input', function () {
            const phoneValue = telefoneInput.value.replace(/\D/g, '');

            if (phoneValue.length !== 10 && phoneValue.length !== 11) {
                telefoneInput.setCustomValidity('Telefone inválido. Insira 10 ou 11 dígitos.');
            } else {
                telefoneInput.setCustomValidity('');
            }
        });

        // Validação de CEP simples (verifica se tem 8 dígitos)
        cepInput.addEventListener('input', function () {
            if (cepInput.value.replace(/\D/g, '').length !== 8) {
                cepInput.setCustomValidity('CEP inválido. Insira 8 dígitos.');
            } else {
                cepInput.setCustomValidity('');
            }
        });

        form.addEventListener('submit', function () {
            // Validação do formulário no envio
            if (!form.checkValidity()) {
                event.preventDefault();
            }
        });
    </script>

</html>

