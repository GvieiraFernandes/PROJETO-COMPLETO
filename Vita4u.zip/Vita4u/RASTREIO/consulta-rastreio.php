

<?php
session_start();
?>
<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<meta charset="utf-8">
		<title>CONSULTA ENTREGA</title>
		<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&family=REM:wght@100;200;300;400;500;600;800;900&display=swap" rel="stylesheet">
        
		<link rel="stylesheet" href="./css/consulta.css">
	</head>
	<body>
    <header>
        <div class="flex-1">

            <h1 id="logo">VITA4U</h1>
            <ul id="cabecalho" class="links-nav">
                    <li>Entregador</li>
                    <li>Restaurante</li>
                    <li>Usuario</li>
                </ul>
        </div>
        <nav class="navbar">
                <ul id="cabecalho-2" class="links-nav">
                    <li>Home</li>
                    <li>Contato</li>
                </ul>
           

            <div id="div-1" class="links-btn">
                <img src="carrinho.png" alt="">
                <img src="personagem.png" alt="">
            </div>
        </div>
    </header>

<div id="mapa">
<iframe 
  width="600"
  height="450"
  style="border:0"
  loading="lazy"
  allowfullscreen
  referrerpolicy="no-referrer-when-downgrade"
  src="https://www.google.com/maps/embed/v1/place?key=API_KEY
    &q=Space+Needle,Seattle+WA">
</iframe>
</div>


<?php
$pdo = new PDO("mysql:host=localhost;dbname=vita4u", "root", "");
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

if (isset($_POST['rastreio'])) {
    // Gerar um número de rastreamento único
     $gera_code = rand(10000000000, 10000000000000);

    // Sanitize as entradas do usuário (se houver alguma)
    $pedido = '123'; // Valor de exemplo para pedido
    $data = date('Y-m-d H:i:s');

    try {
        // Preparar e executar a inserção no banco de dados
        $inseri = $pdo->prepare("INSERT INTO si_rastreio (rastreio_pedido, rastreio_codigo, rastreio_data, rastreio_status) VALUES (:pedido, :code, :data, :stat)");
        $inseri->bindValue(':pedido', $pedido);
        $inseri->bindValue(':code', $gera_code);
        $inseri->bindValue(':data', $data);
        $inseri->bindValue(':stat', 1, PDO::PARAM_INT); // Valor padrão para status (ou substitua pelo valor desejado)
        $inseri->execute();

        ?> <br> <span id="texto-1"> <?php   echo 'Seu código de rastreio é: <b>' . $gera_code . '</b><br>';
    } catch (PDOException $e) {
        echo 'Erro ao inserir no banco de dados: ' . $e->getMessage();
    }
}
?>


<form method="post">
    <button id="numero" name="rastreio" value="rastreio">GERAR CÓDIGO DE RASTREIO</button>
</form>

<form method="post">
    <input id="rastrear-pedido" type="text" name="code_rastreio" required>
    <button id="rastrear-pedido-bt" name="rastrear" value="rastrear">Rastrear Pedido!</button>
</form>


<div class="table-center">
    <table id="tabela" width="800" border="1">
        <tr>
            <td class="tabela">Pedido:</td>
            <td class="tabela">Status:</td>
            <td class="tabela">Data:</td>
            <td class="tabela">Tempo de Entrega: </td> <!-- Adicione a coluna Tempo de Entrega -->
        </tr>
        <?php
        if (isset($_POST['rastrear'])):
            $pedido = '123';
            $codigo = filter_input(INPUT_POST, 'code_rastreio', FILTER_DEFAULT);

            $consulta = $pdo->prepare("SELECT * FROM si_rastreio WHERE rastreio_codigo = :code AND rastreio_pedido = :pedido");
            $consulta->bindValue(':code', $codigo);
            $consulta->bindValue(':pedido', $pedido);
            $consulta->execute();

            $linhas = $consulta->rowCount();

            if ($linhas == 0):
                ?> <br> <span id="texto-2"> <?php  echo 'Não foi encontrado o seu pedido com este código de rastreio: <b>' . $codigo . '</b>, VERIFIQUE a digitação correta do código.';?></span>
                <?php
            else:
                foreach ($consulta as $mostra):
                    ?>
                    <tr>
                        <td><p><?= $mostra['rastreio_pedido'] ?></p></td>
                        <td><p><?= date('d/m/Y H:i:s', strtotime($mostra['rastreio_data'])) ?></p></td>
                        <td><p><?php
                                if ($mostra['rastreio_status'] == 2):
                                    echo '<b>Remessa em Transferência para Região</b>';
                                elseif ($mostra['rastreio_status'] == 3):
                                    echo '<b>Remessa a Destino</b>';
                                elseif ($mostra['rastreio_status'] == 4):
                                    echo '<b>Remessa Entregue</b>';
                                elseif ($mostra['rastreio_status'] == 5):
                                    echo '<b>Remessa Em Atraso</b>';
                                elseif ($mostra['rastreio_status'] == 6):
                                    echo '<b>Remessa Agendada</b>';
                                elseif ($mostra['rastreio_status'] == 7):
                                    echo '<b>Remessa Cancelada</b>';
                                elseif ($mostra['rastreio_status'] == 8):
                                    echo '<b>Remessa Devolvida</b>';
                                else:
                                    echo '<b></b>'; // Não mostrar nada quando o status não corresponder a nenhum caso
                                endif;
                                ?></p></td>
                        <td><p><?= $mostra['tempo_entrega'] ?></p></td> <!-- Exiba o tempo de entrega -->
                    </tr>
                    <?php
                endforeach;
            endif;
        endif;
        ?>
    </table>
</div>

<!-- Resto do código permanece inalterado -->


<footer></footer>


</body>
</html>