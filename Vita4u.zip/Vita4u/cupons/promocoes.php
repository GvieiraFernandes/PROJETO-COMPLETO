<!DOCTYPE html>

<link rel="stylesheet" href="estilo.css">
<link rel="stylesheet" href="reset.css">
<html>
<head>
    <title>Promoções Exclusivas</title>
    
</head>
<body>

  <header>
        <div class="logo">
            <strong class="logo2">VITA4U</strong>
        </div>
        <nav>
            <ul>
                <li><a href="../cadastro_entregador.php">Entregado</a></li>
                <li><a href="../cadastro_restaurante.php">Restaurante</a></li>
                <li><a href="../cadastro_usuario.php">Usuário</a></li>
                <li><a href="../Tela_Alterada/index.html">Home</a></li>
                <li><a href="#">Contato</a></li>
                <span class="icons">
                <a href="../src/vita4u/carrinho.html"><img src="carrinho.png" alt="Carrinho"></a>
                <a href="../pagina_restrita_usuario.php"><img src="usuario.png" alt="Usuário"></a>
                <span>

            </ul>


        </nav>
       
    </header>


    <h1 class="texto">Promoções Exclusivas do Restaurante</h1>

    <div class="cadastro">
    <form action="processar_promocao.php" method="POST">
        <label for="nome">Nome da Promoção:</label>
        <input type="text" id="nome" name="nome" required><br>
        
        <label for="descricao">Descrição da Promoção:</label>
        <textarea id="descricao" name="descricao" required></textarea><br>
        
        <label for="data_inicio">Data de Início:</label>
        <input type="date" id="data_inicio" name="data_inicio" required><br>
        
        <label for="data_fim">Data de Término:</label>
        <input type="date" id="data_fim" name="data_fim" required><br>
        
        <label for="desconto">Desconto:</label>
        <input type="number" id="desconto" name="desconto" step="0.01" required> %<br>
        
        <input type="submit" value="Adicionar Promoção">
    </form>
    </div>

    <?php
    $servidor = "localhost";
	$usuario = "root";
	$senha = "";
	$dbname = "vita4u";
	
	$conexao = mysqli_connect($servidor, $usuario, $senha, $dbname);

    if ($conexao->connect_error) {
        die("Erro na conexão: " . $conexao->connect_error);
    }

    $sql = "SELECT * FROM promocoes";
    $result = $conexao->query($sql);

    if ($result->num_rows > 0) {
        echo "<h2>Promoções Existentes:</h2>";
        echo "<ul>";
        while ($row = $result->fetch_assoc()) {
            echo "<li>";
            echo "Nome: " . $row["nome"] . "<br>";
            echo "Descrição: " . $row["descricao"] . "<br>";
            echo "Data de Início: " . $row["data_inicio"] . "<br>";
            echo "Data de Término: " . $row["data_fim"] . "<br>";
            echo "Desconto: " . $row["desconto"] . "%<br>";
            echo "<a href='editar_promocao.php?id=" . $row["id"] . "'>Editar</a> | ";
            echo "<a href='excluir_promocao.php?id=" . $row["id"] . "'>Excluir</a>";
            echo "</li>";
        }
        echo "</ul>";
    } else {
        echo "Nenhuma promoção encontrada.";
    }
   
    $conexao->close();
    ?>
</body>
</html>
