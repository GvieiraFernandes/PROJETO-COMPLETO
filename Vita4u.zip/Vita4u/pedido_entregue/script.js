document.getElementById('yesBtn').addEventListener('click', function() {
    document.getElementById('loadingContainer').style.display = 'none';
    document.getElementById('confirmationImg').style.display = 'block';
    alert('Obrigado por confirmar! Esperamos que tenha gostado.');
});

document.getElementById('noBtn').addEventListener('click', function() {
    alert('Lamentamos o inconveniente. Vamos verificar isso para você.');
});
