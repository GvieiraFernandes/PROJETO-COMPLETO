<?php
require_once 'db_config.php';

$mensagem = "";


function cadastrarRestaurante($nome, $email, $cnpj, $telefone, $cep, $bairro, $endereco, $cidade, $estado, $senha) {
    global $conn;

    if (verificarEmailExistenteRestaurante($email)) {
        return false; // Email já existe, retorna falso
    }

    $sql = "INSERT INTO restaurante (nome, email, cnpj, telefone, cep, bairro, endereco, cidade, estado, senha) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssssssss", $nome, $email, $cnpj, $telefone, $cep, $bairro, $endereco, $cidade, $estado, $senha);

    return $stmt->execute();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $cnpj = $_POST['cnpj'];
    $telefone = $_POST['telefone'];
    $cep = $_POST['cep'];
    $bairro = $_POST['bairro'];
    $endereco = $_POST['endereco'];
    $cidade = $_POST['cidade'];
    $estado = $_POST['estado'];
    $senha = $_POST['senha'];

    if (cadastrarRestaurante($nome, $email, $cnpj, $telefone, $cep, $bairro, $endereco, $cidade, $estado, $senha)) {
        $mensagem = "Cadastro realizado com sucesso.";
    } else {
        $mensagem = "Erro ao realizar o cadastro ou e-mail já existe.";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Cadastro de Restaurante</title>
    <link rel="stylesheet" type="text/css" href="CSS/cadastro_restaurante"> 
    <script src="JS/cadastro_restaurante.js"></script> 
</head>
<body>
    <form method="POST" action="">
        <h1>Cadastro de Restaurante</h1>

        <label for="nome">Nome:</label><br>
        <input type="text" id="nome" name="nome" required><br>

        <label for "email">E-mail:</label><br>
        <input type="email" id="email" name="email" required><br>

        <label for="cnpj">CNPJ:</label><br>
        <input type="text" id="cnpj" name="cnpj" required maxlength="18" oninput="maskCNPJ(this)"><br>

        <label for="telefone">Telefone:</label><br>
        <input type="text" id="telefone" name="telefone" required maxlength="14" oninput="maskTelefone(this)"><br>

        <label for="cep">CEP:</label><br>
        <input type="text" id="cep" name="cep" required maxlength="9" oninput="maskCEP(this)"><br>

        <label for="bairro">Bairro:</label><br>
        <input type="text" id="bairro" name="bairro" required><br>

        <label for="endereco">Endereço:</label><br>
        <input type="text" id="endereco" name="endereco" required><br>

        <label for="cidade">Cidade:</label><br>
        <input type="text" id="cidade" name="cidade" required><br>

        <label for="estado">Estado:</label><br>
        <input type="text" id="estado" name="estado" required><br>

        <label for="senha">Senha:</label><br>
        <input type="password" id="senha" name="senha" required><br>

        <input type="submit" value="Cadastrar" onclick="return validateForm()">
        
        <?php if (!empty($mensagem)): ?>
            <span><?php echo $mensagem; ?></span>
        <?php endif; ?>

        <div class="links">
            <p>Se já tem cadastro, <a href="login.php">clique aqui para logar</a></p>
            <a href="recuperar_senha.php">Esqueceu a senha?</a>
        </div>
    </form>
</body>
</html>

