<!-- processa_cadastro_cartao.php -->
<?php
require_once '/xampp/htdocs/Vita4u/db_config.php'; // Inclua o arquivo de configuração do banco de dados aqui

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome_titular = $_POST['nome_titular'];
    $numero_cartao = $_POST['numero_cartao'];
    $data_validade = $_POST['data_validade'];
    $codigo_seguranca = $_POST['codigo_seguranca'];

    // Você também precisa obter o ID do usuário logado, de alguma forma.

    // Agora, insira os dados do cartão no banco de dados.
    $stmt = $conn->prepare("INSERT INTO cartoes (nome_titular, numero_cartao, data_validade, codigo_seguranca) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $nome_titular, $numero_cartao, $data_validade, $codigo_seguranca);

    // Substitua "$id_usuario" pelo ID do usuário logado.

    if ($stmt->execute()) {
        echo "Cartão cadastrado com sucesso!";
    } else {
        echo "Erro ao cadastrar o cartão: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>
