<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <form action="enviar-email.php" method="post">
        <p>
            Destinatario: <input type="text" name="destinatario">
        </p>
        <p>
            Assunto: <input type="text" name="assunto">
        </p>
        <p>
            Texto: <input type="text" name="corpo">
        </p>    
        <button>Enviar</button>    
    </form>
</body>
</html>