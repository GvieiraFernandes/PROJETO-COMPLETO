<?php
    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\Exception;

    require './php-mailer/Exception.php';
    require './php-mailer/PHPMailer.php';
    require './php-mailer/SMTP.php';

    function send_mail($destinatario, $assunto, $corpo) {

        $mail = new PHPMailer(true);

        try {
            //Server settings
            $mail->isSMTP();                                            //Send using SMTP
            $mail->Host       = 'smtp.office365.com';                     //Set the SMTP server to send through
            $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
            $mail->Username   = 'vita4u.cotemig@outlook.com';                     //SMTP username
            $mail->Password   = 'PePalare1316';                               //SMTP password
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;            //Enable implicit TLS encryption
            $mail->Port       = 587;

            //Recipients
            $mail->setFrom('vita4u.cotemig@outlook.com', 'Vita4u');
            $mail->addAddress($destinatario);     //Add a recipient

            $mail->isHTML(true);                                  //Set email format to HTML
            $mail->Subject = $assunto;
            $mail->Body    = $corpo;
            $mail->AltBody = $corpo;

            $mail->send();
            echo 'Mensagem envia com sucesso!';

        } catch (Exception $e) {
            echo "Erro no envio de e-mail: $e";
        }

    }
?>