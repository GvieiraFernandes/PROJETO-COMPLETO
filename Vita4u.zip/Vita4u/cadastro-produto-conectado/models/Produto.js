const db = require('./db');

const Produto = db.sequelize.define('produtos', {
    id_produtos: {
        type: db.Sequelize.INTEGER,
        autoIncrement: true,
        allowNull: false,
        primaryKey: true
    },
    nome: {
        type: db.Sequelize.STRING,
        allowNull: false,
    },
    descricao: {
        type: db.Sequelize.STRING,
        allowNull: true,
    },
    preco: {
        type: db.Sequelize.FLOAT,
        allowNull: false,
    }
});

//Criar a tabela
//User.sync();
//Verificar se há alguma diferença na tabela, realiza a alteração
//User.sync({ alter: true })

module.exports = Produto;