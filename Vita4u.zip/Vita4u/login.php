<?php
session_start();
require_once 'db_config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $senha = $_POST['senha'];

    // Verifica se o email e senha correspondem a um usuário
    $sql = "SELECT * FROM usuario WHERE email = '$email' AND senha = '$senha'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $_SESSION['usuario'] = $result->fetch_assoc();
        header("Location: pagina_restrita_usuario.php");
        exit();
    }

    // Verifica se o email e senha correspondem a um entregador
    $sql = "SELECT * FROM entregador WHERE email = '$email' AND senha = '$senha'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $_SESSION['entregador'] = $result->fetch_assoc();
        header("Location: pagina_restrita_entregador.php");
        exit();
    }

    // Verifica se o email e senha correspondem a um restaurante
    $sql = "SELECT * FROM restaurante WHERE email = '$email' AND senha = '$senha'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $_SESSION['restaurante'] = $result->fetch_assoc();
        header("Location: pagina_restrita_restaurante.php");
        exit();
    }

    // Verifica se o email não existe em nenhum dos tipos de conta
    $sql = "SELECT * FROM usuario WHERE email = '$email'";
    $result_usuario = $conn->query($sql);

    $sql = "SELECT * FROM entregador WHERE email = '$email'";
    $result_entregador = $conn->query($sql);

    $sql = "SELECT * FROM restaurante WHERE email = '$email'";
    $result_restaurante = $conn->query($sql);

    if ($result_usuario->num_rows === 0 && $result_entregador->num_rows === 0 && $result_restaurante->num_rows === 0) {
        $erro = "Usuário não cadastrado.";
    } else {
        $erro = "E-mail ou senha incorretos.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <link rel="stylesheet" type="text/css" href="CSS/login.css">
</head>
<body>
    <div class="container">
        <h1>Login</h1>
        <?php if (isset($erro)): ?>
            <div class="msg_erro"><?php echo $erro; ?></div>
        <?php endif; ?>
        <form method="POST" action="">
            <input type="email" name="email" placeholder="E-mail" required>
            <input type="password" name="senha" placeholder="Senha" required>
            <input type="submit" value="Login">
            <a class="recuperarsenha" href="recuperar_senha.php">Esqueci minha senha</a>
        </form>
        <div class="links">
            <p>Não possui cadastro? <br> <a href="cadastro.php">Clique aqui para se cadastrar</a></p>
        </div>
    </div>
</body>
</html>

