const express = require('express');
const app = express();
const handlebars = require("express-handlebars");
//const _handlebars = require('handlebars');
const bodyParser = require("body-parser");
const Produto = require('/xampp/htdocs/Vita4u/cadastro-produto-conectado/models/Produto');

const moment = require('moment')
//const {allowInsecurePrototypeAccess} = require('@handlebars/allow-prototype-access')


app.engine('handlebars',handlebars({
    defaultLayout: 'main',
    /*helpers:{
        formatDate:(date)=>{
            return moment(date).format('DD/MM/YYYY')
        }
    }*/

}))
/*app.engine('handlebars', handlebars({
    handlebars: allowInsecurePrototypeAccess(_handlebars)
}))*/
app.set('view engine', 'handlebars')

app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json())

//Rotas
app.get('/xampp/htdocs/Vita4u/cadastro-produto-conectado/views/produto', function(req, res){
    Produto.findAll().then(function(produtos){
        res.render('produto',{produtos:produtos});
    })
    
});

app.get('/xampp/htdocs/Vita4u/cadastro-produto-conectado/views/cad-produto', function(req, res){
    res.render('cad-produto');
});


app.post('/add-produto', function(req, res){
    Produto.create({
        nome: req.body.nome,
        descricao: req.body.descricao,
        preco: req.body.preco
    }).then(function(){
        res.redirect('/produto')
        //res.send("Pagamento cadastro com sucesso!")
    }).catch(function(erro){
        res.send("Erro: Produto não foi cadastrado com sucesso!" + erro)
    })
    //res.send("Nome: " + req.body.nome + "<br>Valor: " + req.body.valor + "<br>") 
});

//criando a tabela
function setList(list){
    var table = '<thead><tr><td>NOME</td><td>DESCRIÇÃO</td><td>CATEGORIA</td><td>PREÇO</td><td>QUANTIDADE</td></tr></thead><tbody>';
    for(var key in list){
        table += '<tr><td>'+ formatDesc(list[key].name) +'</td><td>'+ formatAmount(list[key].desc) +'</td><td>'+ formatValue(list[key].value) +'</td><td><button class="btn btn-default" onclick="setUpdate('+key+');">Edit</button> <button class="btn btn-default" onclick="deleteData('+key+');">Delete</button></td></tr>';
    }
    table += '</tbody>';

    document.getElementById('listTable').innerHTML = table;
    getTotal(list);
    saveListStorage(list);
}

document.getElementById("add").addEventListener("click",addData)
//adicionar novo produto
function addData(){
    console.log('teste')
    if(!validation()){
        return;
    }
    var name = document.getElementById("name").value;
    var desc = document.getElementById("desc").value;
    var catego = document.getElementById("catego").value;
    var value = document.getElementById("value").value;
    var quant = document.getElementById("quant").value;

    list.unshift({"name":name, "desc":desc , "catego":catego , "value":value, "quant":quant });
    console.log(setList(list));
    console.log(entrou)

    
}

//botões de editar
function setUpdate(id){
    var obj = list[id];
    document.getElementById("name").value = obj.name;
    document.getElementById("desc").value = obj.desc;
    document.getElementById("catego").value = obj.catego;
    document.getElementById("value").value = obj.value;
    document.getElementById("quant").value = obj.quant;
    document.getElementById("btnUpdate").style.display = "inline-block";
    document.getElementById("btnAdd").style.display = "none";

    document.getElementById("inputIDUpdate").innerHTML = '<input id="idUpdate" type="hidden" value="'+id+'">';
}

//limpa os campos de editar
function resetForm(){
    document.getElementById("name").value = "";
    document.getElementById("desc").value = "";
    document.getElementById("catego").value = "";
    document.getElementById("value").value = "";
    document.getElementById("quant").value = "";
    document.getElementById("btnUpdate").style.display = "none";
    document.getElementById("btnAdd").style.display = "inline-block";
    
    document.getElementById("inputIDUpdate").innerHTML = "";
    document.getElementById("errors").style.display = "none";
}

//atualizando os dados
function updateData(){
    if(!validation()){
        return;
    }
    var id = document.getElementById("idUpdate").value;
    var name = document.getElementById("name").value;
    var desc = document.getElementById("desc").value;
    var catego = document.getElementById("catego").value;
    var value = document.getElementById("value").value;
    var quant = document.getElementById("quant").value;

    list[id] = {"name":name, "desc":desc , "catego":catego , "value":value, "quant":quant };
    resetForm();
    setList(list);
}

function validation(){
    var name = document.getElementById("name").value;
    var desc = document.getElementById("desc").value;
    var catego = document.getElementById("catego").value;
    var value = document.getElementById("value").value;
    var quant = document.getElementById("quant").value;
    var errors = "";
    document.getElementById("errors").style.display = "none";

    if(name === ""){
        errors += '<p>Preencha o campo NOME</p>';
    }

    if(desc === ""){
        errors += '<p>Preencha o campo NOME</p>';
    }

    if(catego === ""){
        errors += '<p>Preencha o campo NOME</p>';
    }

    if(value === ""){
        errors += '<p>Preencha o campo VALOR!</p>';
    }else if(value != parseFloat(value)){
        errors += '<p>Preencha com um valor válido!</p>';
    }

    if(quant === ""){
        errors += '<p>Preencha o campo QUANTIDADE!</p>';
    }else if(quant != parseInt(quant)){
        errors += '<p>Preencha com um valor válido!</p>';
    }

    if(errors != ""){
        document.getElementById("errors").style.display = "block";
        document.getElementById("errors").innerHTML = "<h3>Error:</h3>" + errors;
        return 0;
    }else{
        return 1;
    }
}

//salvando em storage
function saveListStorage(list){
    var jsonStr = JSON.stringify(list);
    localStorage.setItem("list",jsonStr);
}

//verifica se já tem algo salvo
function initListStorage(){
    var testList = localStorage.getItem("list");
    if(testList){
        list = JSON.parse(testList);
    }
    setList(list);
}

initListStorage();

app.get('/del-produto:id_produtos',function(req,res){
    Produto.destroy({

        where:{'id_produtos':req.params.id_produtos}

    }).then(function(){
        res.send("Produto deletado");
    }).catch(function(erro){
        res.send("Produto não deletado");
    })
});

app.listen(5500);