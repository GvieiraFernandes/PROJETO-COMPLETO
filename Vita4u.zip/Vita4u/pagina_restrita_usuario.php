<?php
session_start();
require_once 'db_config.php';

// Verifica se o usuário está autenticado
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}

// Recupera as informações do perfil do usuário do banco de dados
$id_usuario = $_SESSION['usuario']['id_usuario'];
$sql = "SELECT * FROM usuario WHERE id_usuario = '$id_usuario'";
$result = $conn->query($sql);

if ($result->num_rows == 1) {
    $perfil = $result->fetch_assoc();
} else {
    // Perfil não encontrado
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Área Privada do Usuário</title>
    <link rel="stylesheet" type="text/css" href="CSS/restrita_usuario.css">
</head>
<body>
    <div class="container">
        <h1>Bem-vindo, <?php echo $perfil['nome']; ?></h1>
        <div class="profile-info">
            <h2>Informações do Perfil</h2>
            <p>Nome: <?php echo $perfil['nome']; ?></p>
            <p>Email: <?php echo $perfil['email']; ?></p>
            <p>CPF: <?php echo $perfil['cpf']; ?></p>
            <p>CEP: <?php echo $perfil['cep']; ?></p>
            <!-- Outras informações do perfil -->

            <a href="editar-perfil/editar_perfil_usuario.php" class="edit-link">Editar Perfil</a>
            <a href="cadastro_cartao/index.html" class="edit-link">Cadastro de Cartão</a>
            <a href="logout.php" class="edit-link">Sair</a>
        </div>
    </div>
</body>
</html>

