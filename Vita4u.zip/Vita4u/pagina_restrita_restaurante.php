<?php
session_start();
require_once 'db_config.php';

// Verifica se o restaurante está autenticado
if (!isset($_SESSION['restaurante'])) {
    header("Location: login.php");
    exit();
}

// Recupera as informações do restaurante logado do banco de dados
$id_restaurante = $_SESSION['restaurante']['id_restaurante'];
$sql = "SELECT * FROM restaurante WHERE id_restaurante = '$id_restaurante'";
$result = $conn->query($sql);

if ($result->num_rows == 1) {
    $perfil = $result->fetch_assoc();
} else {
    // Perfil não encontrado
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Área Restrita do Restaurante</title>
    <link rel="stylesheet" type="text/css" href="CSS/restritra_restaurante.css">
</head>
<body>
    <div class="container">
        <h1>Bem-vindo, <?php echo $perfil['nome']; ?>!</h1>
        <p>CNPJ: <?php echo $perfil['cnpj']; ?></p>
        <p>Email: <?php echo $perfil['email']; ?></p>
        <p>Cep: <?php echo $perfil['cep']; ?></p>
        <p>Telefone: <?php echo $perfil['telefone']; ?></p>
        <a href="editar-perfil/editar_perfil_restaurante.php" class="button">Editar Perfil</a>
        <a href="contagem_pedidos/index.html" class="button button-pedidos">Ver Contagem de Pedidos</a>
        <a href="logout.php" class="button">Sair</a>
    </div>
</body>
</html>


