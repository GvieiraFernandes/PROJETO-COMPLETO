<?php
if (isset($_GET["id"])) {
    $id = $_GET["id"];

    $servidor = "localhost";
	$usuario = "root";
	$senha = "";
	$dbname = "vita4u";
	
	
	$conexao = mysqli_connect($servidor, $usuario, $senha, $dbname);

  
    if ($conexao->connect_error) {
        die("Erro na conexão: " . $conexao->connect_error);
    }

    $sql = "DELETE FROM promocoes WHERE id = ?";
    $stmt = $conexao->prepare($sql);
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        header("Location: promocoes.php"); 
    } else {
        echo "Erro ao excluir a promoção: " . $stmt->error;
    }

    $conexao->close();
}
?>
