<?php
require '/xampp/htdocs/Vita4u/lib/PHPMailer-master/src/PHPMailer.php';
require '/xampp/htdocs/Vita4u/lib/PHPMailer-master/src/SMTP.php';
require '/xampp/htdocs/Vita4u/lib/PHPMailer-master/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

function enviarEmail($email, $assunto, $mensagem)
{
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host = 'sandbox.smtp.mailtrap.io';
        $mail->SMTPAuth = true;
        $mail->Username = '4e4cd989c0fbe1';
        $mail->Password = '07ca79ea59b625';
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;

        $mail->setFrom('Suporte@vita4u.com', 'Vita4u');
        $mail->addAddress($email);
        $mail->isHTML(true);
        $mail->Subject = $assunto;
        $mail->Body = $mensagem;

        $mail->send();
        return true;
    } catch (Exception $e) {
        return false;
    }
}
?>
