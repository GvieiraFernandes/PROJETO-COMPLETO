<?php
session_start();
require_once 'db_config.php';

// Verifica se o entregador está autenticado
if (!isset($_SESSION['entregador'])) {
    header("Location: login.php");
    exit();
}

// Recupera as informações do entregador logado do banco de dados
$id_entregador = $_SESSION['entregador']['id_entregador'];
$sql = "SELECT * FROM entregador WHERE id_entregador = '$id_entregador'";
$result = $conn->query($sql);

if ($result->num_rows == 1) {
    $perfil = $result->fetch_assoc();
} else {
    // Perfil não encontrado
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Área Restrita do Entregador</title>
    <link rel="stylesheet" type="text/css" href="CSS/restrita_entregador">
</head>
<body>
  <div class="container">
    <h1>Bem-vindo, <?php echo $perfil['nome']; ?>!</h1>
     <p>CPF: <?php echo $perfil['cpf']; ?></p>
      <p>Email: <?php echo $perfil['email']; ?></p>
       <p>Telefone: <?php echo $perfil['telefone']; ?></p>
      <p><a href="editar-perfil/editar_perfil_entregador.php" class="button">Editar Perfil</a></p>
    <p><a href="logout.php" class="button logout">Sair</a></p>
  </div>
</body>
</html>

