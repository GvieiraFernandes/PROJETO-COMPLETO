window.addEventListener('DOMContentLoaded', function() {
    var cpfInput = document.getElementById('cpf');
    var emailInput = document.getElementById('email');
    var telefoneInput = document.getElementById('telefone');
  
    cpfInput.addEventListener('input', function() {
      var cpf = cpfInput.value;
      cpf = cpf.replace(/\D/g, '');
      cpf = cpf.slice(0, 11);
      cpf = cpf.replace(/(\d{3})(\d)/, '$1.$2');
      cpf = cpf.replace(/(\d{3})(\d)/, '$1.$2');
      cpf = cpf.replace(/(\d{3})(\d{1,2})$/, '$1-$2');
      cpfInput.value = cpf;
    });
  
    emailInput.addEventListener('input', function() {
      var email = emailInput.value;
      emailInput.value = email.toLowerCase();
    });
  
    telefoneInput.addEventListener('input', function() {
      var telefone = telefoneInput.value;
      telefone = telefone.replace(/\D/g, '');
      telefone = telefone.slice(0, 11);
      telefone = telefone.replace(/(\d{2})(\d)/, '($1) $2');
      telefone = telefone.replace(/(\d{4})(\d)/, '$1-$2');
      telefone = telefone.replace(/(\d{4})-(\d)(\d{4})/, '$1$2-$3');
      telefoneInput.value = telefone;
    });
  });
  
  